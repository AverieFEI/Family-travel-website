@echo off
chcp 65001 >nul
title 家庭旅行网站 - 云同步版
echo.
echo   🧳 正在启动家庭旅行网站（云同步版）...
echo.

REM 优先使用系统 Node，找不到则用 WorkBuddy 自带的 Node
set NODE_EXE=node
where node >nul 2>nul
if errorlevel 1 (
  if exist "C:\Users\27700\.workbuddy\binaries\node\versions\22.22.2\node.exe" (
    set NODE_EXE=C:\Users\27700\.workbuddy\binaries\node\versions\22.22.2\node.exe
  ) else (
    echo   ❌ 未找到 Node.js，请先安装：https://nodejs.org
    pause
    exit /b 1
  )
)

start "" http://localhost:8390
"%NODE_EXE%" server.js
pause
